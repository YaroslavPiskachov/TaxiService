CREATE PROCEDURE `add_shift_after`(`current_worker_Id` TINYINT, `previous_worker_id` TINYINT)
  BEGIN
	DECLARE last_date DATETIME;
	SELECT MAX(Time_out) INTO last_date 
    FROM shifts WHERE id_worker=previous_worker_id;
    
    INSERT INTO shifts 
    VALUES(last_date,FROM_UNIXTIME(UNIX_TIMESTAMP(last_date) + 3600*8),4,current_worker_id);     
END