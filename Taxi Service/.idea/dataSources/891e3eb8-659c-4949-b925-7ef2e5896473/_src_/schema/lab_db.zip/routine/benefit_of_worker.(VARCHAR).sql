CREATE PROCEDURE `benefit_of_worker`(`name` VARCHAR)
  BEGIN
	SELECT Full_name, SUM(Price) FROM benefit WHERE Full_name LIKE name;
END