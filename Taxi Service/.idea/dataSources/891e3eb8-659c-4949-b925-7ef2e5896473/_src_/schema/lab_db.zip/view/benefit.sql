CREATE VIEW `benefit` AS
  SELECT
    `lab_db`.`driver`.`Full_name` AS `Full_name`,
    `lab_db`.`booking`.`Price`    AS `Price`
  FROM ((`lab_db`.`driver`
    JOIN `lab_db`.`shifts` ON ((`lab_db`.`driver`.`id_worker` = `lab_db`.`shifts`.`id_worker`))) JOIN `lab_db`.`booking`
      ON ((`lab_db`.`shifts`.`id_shift` = `lab_db`.`booking`.`id_shift`)))